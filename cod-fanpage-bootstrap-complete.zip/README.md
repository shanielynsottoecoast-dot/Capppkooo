# CALL OF DUTY Fan Page 🎖️

A dark military-themed fan page for Call of Duty, built with **Bootstrap 5** and custom CSS.

**"More than a Game. It's a Mission."**

## Features

- **Responsive design** — Bootstrap 5.3.3 grid & components (navbar, cards, forms)
- **Dark military theme** — custom CSS overlay (#0d0d0d background, #ff9900 orange accents)
- **Google Fonts** — Oswald, Rajdhani & Roboto
- **Sections** — Hero, About (with stats), Game Modes (Multiplayer / Battle Royale / Zombies), Loadout, Contact
- **Vanilla JS extras** — scroll-spy nav highlighting, mobile menu auto-close, demo form handler

## Project Structure

```
cod-fanpage-bootstrap/
├── index.html          # Main page
├── style.css           # Custom military theme styles
├── images/             # Hero, game mode, weapon & operator images
└── README.md
```

## Getting Started

1. Clone or download this repository.
2. Open `index.html` in your browser — no build step required.

Or serve it locally:

```bash
python3 -m http.server 8001
```

Then visit `http://localhost:8001`.

## Tech Stack

- HTML5
- CSS3 (custom theme on top of Bootstrap)
- Bootstrap 5.3.3 (CDN)
- Vanilla JavaScript

## Credits

Fan page made by **GHOST-907** (SHANIELYN SOTTO) — Call of Duty fan project, non-commercial. Call of Duty is a trademark of Activision Publishing, Inc. This is an unofficial fan page.
